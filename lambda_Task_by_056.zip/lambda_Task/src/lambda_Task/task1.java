/**
 * 
 */
package lambda_Task;

import java.util.Arrays;

interface MyInterface {

	double apply(double[] arr);
	}
public class task1 {

 public static void main( String[] args ) {

 // declare a reference to MyInterface
 MyInterface ref;
 
 double[] array = {
		 10,20,30,40
 };
 // lambda expression
 ref = (arr) -> Arrays.stream(array).sum();

 System.out.println("Sum of Array = " + ref.apply(array));
 ref = (arr) -> Arrays.stream(array).count();
 System.out.println("Count of Array = " + ref.apply(array));
 ref = (arr) -> Arrays.stream(array).average().getAsDouble();
 System.out.println("Average of Array = " + ref.apply(array));
 ref = (arr) -> Arrays.stream(array).max().getAsDouble();
 System.out.println("Max of Array = " + ref.apply(array));
 ref = (arr) -> Arrays.stream(array).min().getAsDouble();
 System.out.println("Min of Array = " + ref.apply(array));
 } 
}