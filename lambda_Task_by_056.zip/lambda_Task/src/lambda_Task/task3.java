/**
 * 
 */
package lambda_Task;

/**
 * @author SaadAhmad
 *
 */
public class task3 {  
    public static double saySomething(double[] arr){  
    	for (double d : arr) {
    		 System.out.println(d);
    		 
		}
    	return 0;
        
    }  
    public static double incrementByPi(double[] arr){  
    	System.out.println("Incrment Element by PI ");
		
    	for (double d : arr) {
    		System.out.println(d+Math.PI);
    		
    	}
    	return 0;
    	
    }  
    public static double getNumberLessThanE(double[] arr){ 
    	System.out.println("Elements Less Than E");
		
    	for (double d : arr) {
    		if (d<Math.E) {
    			System.out.println(d);
			}else {
				System.out.println("Cannot Print ");
			}
    		
    	}
    	return 0;
    	
    }  
    public static void main(String[] args) {  
    	double[] array = {10,20,30,40};
        // Referring static method  
    	MyInterface sayable = task3::saySomething; 
    	
        // Calling interface method  
        sayable.apply(array);  
	MyInterface obj = task3::incrementByPi; 
    	
        // Calling interface method  
        obj.apply(array);  
	MyInterface obj2 = task3::getNumberLessThanE; 
    	
        // Calling interface method  
        obj2.apply(array);  
    }  
}  