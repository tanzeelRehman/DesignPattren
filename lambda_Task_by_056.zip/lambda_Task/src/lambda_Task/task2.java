package lambda_Task;

import java.util.Arrays;

  class Lambda {
	    // A static method for checking if  a number is positive
	    public static double getSum(double[] n) {
	        return Arrays.stream(n).sum();
	    }
	    public static double getAverage(double[] n) {
	    	return Arrays.stream(n).average().getAsDouble();
	    }
	    public static double getCount(double[] n) {
	    	return Arrays.stream(n).count();
	    }
	    public static double getMax(double[] n) {
	    	return Arrays.stream(n).max().getAsDouble();
	    }
	    public static double getMin(double[] n) {
	    	return Arrays.stream(n).min().getAsDouble();
	    } 
	}

public class task2 {

 public static void main( String[] args ) {

 // declare a reference to MyInterface
 MyInterface ref;
 
 double[] array = {10,20,30,40};
 System.out.println("Sum of Array = " + Lambda.getSum(array));
 System.out.println("Count of Array = " + Lambda.getCount(array));
 System.out.println("Average of Array = " + Lambda.getAverage(array));
 System.out.println("Max of Array = " +Lambda.getMax(array));

 System.out.println("Min of Array = " + Lambda.getMin(array));
 } 
 
 
 
}